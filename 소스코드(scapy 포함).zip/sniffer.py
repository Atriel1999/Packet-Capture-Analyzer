from scapy.all import *
from scapy.layers.inet import *

protocols = {1:'ICMP', 6:'TCP', 17:'UDP'}

method = int(input("패킷 수신방식 (갯수:1, 시간:2, 종료:3): "))
count = 1

def check_method(method):
    if method == 1:
        temp = int(input("수신할 패킷의 갯수를 입력하세요: "))
        sniffing(method, temp)
    elif method == 2:
        temp = int(input("패킷 수신 시간을 입력하세요 (단위:초): "))
        sniffing(method, temp)
    elif method == 3:
        print("3번을 입력하셨습니다 프로그램을 종료합니다")
        exit()
    else:
        print("다시 입력하세요(1 ~ 3)")
        check_method(method)

def sniffing(type, temp):
    print("Sniffing Start")
    if type == 1:  ##갯수로 수신
        print("패킷을 "+str(temp)+"회 수신합니다.")
        time.sleep(1)
        sniff(filter="ip", prn=showPacket, count=temp)
    elif type == 2: ##시간으로 수신
        print("패킷을 " + str(temp) + "초 수신합니다.")
        time.sleep(1)
        sniff(filter="ip", prn=showPacket, timeout=temp)
    print("Sniffing End")

    # if count == 1:
    #     print("No Packet")
    #     sys.exit()
    # else:
    #     print("Total Packet: %s" % (count - 1))
    #     file_name = input("Enter File Name: ")
    #     wrpcap(str(file_name), pcap_file)


def showPacket(packet):
    global count
    proto = packet[0][1].proto

    print("-------------------------------------------------------")
    # 이더넷 헤더
    # 목적지 주소
    # 출발주소
    # 프로토콜 종류

    #아이피헤더
    #version
    #ihl 이더넷 헤더 lenght
    #tos (type of service)
    #len (total length)
    #id
    #flags (아이피 플래그 (공백) ''
    #frag (fragment offset :0)
    #ttl (타임투리브)
    #proto (프로토콜
    #chksum (헤더 체크섬)
    #src
    #dst

    # packet[0][0]은 MAC주소 계층
    # packet[0][1]은 IP계층, packet[ip]로도 접근가능하다.
    # packet[0][2]은 TCP, UDP, ICMP계층이며, packet[TCP], packet[UDP], packet[ICMP]로도 접근가능하다.
    print("\n")
    print(str(count) + "번 패킷")
    count = count + 1
    print("======================ETH HEADER======================")
    print("DESTINATION Physical Address - [{}]\nSOURCE\t\tPhysical Address - [{}]\nnext protocal\t\t\t\t - [{}]입니다."
          .format(packet.dst, packet.src, hex(packet.type))) ## packet.type 2048(0x800)은 IPv4
    print("======================================================")
    print("")
    print("=======================IP HEADER=======================")
    print("VERS\t\t\t\t\t - [{}]\t<IPv{}>" .format(packet[0][1].version, packet[0][1].version))
    print("H.LEN\t\t\t\t\t - [{} Byte]".format(packet[0][1].ihl))
    print("SERVICE TYPE\t\t\t - [{}] <BASE>".format(hex(packet[0][1].tos)))
    print("TOTAL LENGTH\t\t\t - [{} Byte]".format(packet[0][1].len))
    print("IDENTIFICATION\t\t\t - [{}]".format(hex(packet[0][1].id)))
    print("<Flag>Do not Fragment\t - [0X{}] <해당 패킷을 폐기>".format(packet[0][1].flags))
    print("FRAGMENT OFFSET\t\t\t - [{} Byte]".format(packet[0][1].frag))
    print("TIME TO LIVE\t\t\t - [{}]".format(hex(packet[0][1].ttl)))
    print("TYPE\t\t\t\t\t - ['{}' 형식입니다.]" .format(protocols[packet[0][1].proto]))
    print("HEADER CHECKSUM\t\t\t - [{}]".format(packet[0][1].chksum))
    print("SOURCE ADDRESS\t\t\t - [{}]".format(packet[0][1].src))
    print("DESTINATION ADDRESS\t\t - [{}]".format(packet[0][1].dst))
    print("=======================================================\n")

    if proto in protocols:
        # ICMP
        if proto == 1:
            print("=======================ICMP HEADER=======================")
            print("Type\t\t\t\t - {}".format(packet[ICMP].type))  # 헤더,데이터 체크
            print("Code\t\t\t\t - {}".format(packet[ICMP].code))  # 헤더,데이터 체크
            print("Checksum\t\t\t - {}".format(packet[UDP].chksum))  # 헤더,데이터 체크
            print("=========================================================\n")

        # TCP
        if proto == 6:
            print("=======================TCP HEADER=======================")
            print("Source port\t\t\t\t - {}" .format(packet[TCP].sport)) #출발지포트번호
            print("Destination port\t\t - {}".format(packet[TCP].dport)) #목적지포트번호
            print("Sequence Number\t\t\t - {}".format(packet[TCP].seq)) #Sequence Number
            print("Acknowledgement Number\t - {}".format(packet[TCP].ack)) #Acknowledgment Number
            print("Offset\t\t\t\t\t - {}".format(packet[TCP].dataofs)) #오프셋, 헤더길이 필드
            print("Reserved\t\t\t\t - {}".format(packet[TCP].reserved)) #예약된필드 (사용안함)
            print("TCP flags\t\t\t\t - {}".format(packet[TCP].flags)) #tcp플래그 (UAPRSF, Urgent,Ack,Push,Rest,Syn,Fin)
            print("Window\t\t\t\t\t - {}".format(packet[TCP].window)) #수신버퍼 용량 통보해서 얼마만큼 데이터받을수있는지 상대에게 알려주는 흐름제어필드
            print("Checksum\t\t\t\t - {}".format(packet[TCP].chksum)) #체크썸
            print("Urgent Pointer\t\t\t - {}".format(packet[TCP].urgptr)) #Urgent와 세트로 어디서부터 긴급값인지 알려주는 플래그
            print("TCP Options\t\t\t\t - {}".format(packet[TCP].options)) #variable lenght, optional
            print("========================================================\n")


        # UDP
        if proto == 17:
            print("=======================UDP HEADER=======================")
            print("Source Port Number\t\t - {}".format(packet[UDP].sport))  # 출발지포트번호
            print("Destination Port Number\t - {}".format(packet[UDP].dport))  # 목적지포트번호
            print("Length\t\t\t\t\t - {}".format(packet[UDP].len))  # UDP헤데+데이터 길이
            print("Checksum\t\t\t\t - {}".format(packet[UDP].chksum))  # 헤더,데이터 체크
            print("========================================================\n")

check_method(method)
